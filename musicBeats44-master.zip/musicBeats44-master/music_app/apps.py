from django.apps import AppConfig


class MusicAppConfig(AppConfig):
    name = 'music_app'
